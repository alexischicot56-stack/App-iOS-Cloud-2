import SwiftUI

struct ContentView: View {
    // États pour gérer les animations
    @State private var isIslandExpanded = false
    @State private var isPlaying = false

    var body: some View {
        ZStack(alignment: .top) {
            // Fond d'écran style iOS 26 (Gradients fluides)
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.indigo.opacity(0.9), Color.black]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            // Contenu principal de l'application
            VStack(spacing: 40) {
                Spacer().frame(height: 150)

                Text("Vision iOS 26")
                    .font(.system(size: 46, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(color: .white.opacity(0.3), radius: 10, x: 0, y: 5)

                Text("Optimisé pour iPhone 17 Pro Max")
                    .font(.title3)
                    .foregroundColor(.white.opacity(0.7))

                Spacer()

                // Bouton pour interagir avec la Dynamic Island
                Button(action: {
                    // Animation élastique fluide typique d'iOS
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6, blendDuration: 0.5)) {
                        isIslandExpanded.toggle()
                        isPlaying.toggle()
                    }
                }) {
                    Text(isIslandExpanded ? "Réduire l'île" : "Interagir avec l'île")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.ultraThinMaterial)
                        .cornerRadius(25)
                        .foregroundColor(.white)
                        .padding(.horizontal, 40)
                        .shadow(radius: 10)
                }

                Spacer().frame(height: 50)
            }

            // --- DYNAMIC ISLAND SIMULÉE ---
            DynamicIslandView(isExpanded: $isIslandExpanded, isPlaying: $isPlaying)
                // Ajustement du padding pour correspondre à l'encoche physique
                .padding(.top, 12) 
        }
    }
}

// Vue dédiée à la Dynamic Island
struct DynamicIslandView: View {
    @Binding var isExpanded: Bool
    @Binding var isPlaying: Bool

    var body: some View {
        HStack {
            if isExpanded {
                // Animation d'onde sonore à gauche
                Image(systemName: "waveform")
                    .foregroundColor(.green)
                    .font(.title2)
                    // Effet d'animation iOS natif (nécessite iOS 17 minimum)
                    .symbolEffect(.bounce.up.byLayer, options: .repeating, value: isPlaying)
                    .padding(.leading, 20)

                Spacer()

                VStack(alignment: .center, spacing: 4) {
                    Text("Musique Spatiale")
                        .font(.caption.weight(.bold))
                        .foregroundColor(.white)
                    Text("Lecture en cours...")
                        .font(.caption2)
                        .foregroundColor(.gray)
                }

                Spacer()

                // Icône à droite
                Image(systemName: "airpodsmax")
                    .foregroundColor(.white)
                    .font(.title2)
                    .padding(.trailing, 20)
            }
        }
        // Changement de taille dynamique
        .frame(width: isExpanded ? 360 : 125, height: isExpanded ? 85 : 37)
        .background(Color.black)
        .clipShape(Capsule())
        // Ombre pour faire ressortir l'île du fond
        .shadow(color: .black.opacity(0.5), radius: 15, x: 0, y: 10)
        // L'animation clé de la Dynamic Island
        .animation(.interactiveSpring(response: 0.4, dampingFraction: 0.5, blendDuration: 0.5), value: isExpanded)
    }
}

#Preview {
    ContentView()
}